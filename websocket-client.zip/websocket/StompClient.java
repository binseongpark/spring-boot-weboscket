package sfaas.mes.websocket;

import javax.annotation.PostConstruct;

import org.springframework.messaging.simp.stomp.StompSession;
import org.springframework.stereotype.Component;

@Component
public class StompClient {
    private StompSession session;

    @PostConstruct
    public void init() {
        //
    }

    public StompSession getSession() {
        System.out.println("@@@@ getSession: " + session);
        return session;
    }

    public void setSession(StompSession session) {
        this.session = session;
    }
}
