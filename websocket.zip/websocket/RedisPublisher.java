package sfaas.mes.websocket;

import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.listener.ChannelTopic;
import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Service
public class RedisPublisher {

    private final RedisTemplate<String, Object> redisTemplate;
    //private final StringRedisTemplate redisTemplate;

    public void publish(ChannelTopic topic, String message) {
        System.out.println("@@@@ publish 발생");
        System.out.println(topic.getTopic());
        System.out.println(message);
        redisTemplate.convertAndSend(topic.getTopic(), message);
    }
}
