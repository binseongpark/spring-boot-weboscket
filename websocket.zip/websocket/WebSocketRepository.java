package sfaas.mes.websocket;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.listener.ChannelTopic;
import org.springframework.data.redis.listener.RedisMessageListenerContainer;
import org.springframework.stereotype.Repository;

import lombok.RequiredArgsConstructor;
import sfaas.mes.util.Util;

@Configuration
@RequiredArgsConstructor
@Repository
public class WebSocketRepository {
    private final RedisMessageListenerContainer redisMessageListener;
    private final RedisSubscriber redisSubscriber;
    private static final String redisWebsocketKey = "Websocket";
    private final RedisTemplate<String, Object> redisTemplate;

    // private final StringRedisTemplate redisTemplate;

    private HashOperations<String, String, WebSocketTopic> opsHashTopic;
    private Map<String, ChannelTopic> topics;

    @Value("${server.display-name}")
    private String domain;

    @PostConstruct
    private void init() {
        opsHashTopic = redisTemplate.opsForHash();
        topics = new HashMap<>();

        /**
         * socketMessage.getTopic() :
         * log-{domain}
         * notification-{domain}
         * scada-{domain}
         * usercontrol-{domain}
         */
        domain = Util.split(domain, "-")[0];

//        createTopic("log-" + domain);
//        connectionTopic("log-" + domain);
//
//        createTopic("notification-" + domain);
//        connectionTopic("notification-" + domain);
//
//        createTopic("scada-" + domain);
//        connectionTopic("scada-" + domain);
//
//        createTopic("usercontrol-" + domain);
//        connectionTopic("usercontrol-" + domain);
    }

    public List<WebSocketTopic> findAllBus() {
        return opsHashTopic.values(redisWebsocketKey);
    }

    public WebSocketTopic createTopic(String topic) {
        WebSocketTopic websocketTopic = WebSocketTopic.create(topic);
        opsHashTopic.put(redisWebsocketKey, websocketTopic.getTopic(), websocketTopic);
        return websocketTopic;
    }

    public void connectionTopic(String topic) {
        ChannelTopic channelTopic = topics.get(topic);
        if (channelTopic == null)
            channelTopic = new ChannelTopic(topic);
        redisMessageListener.addMessageListener(redisSubscriber, channelTopic);
        topics.put(topic, channelTopic);
    }

    public ChannelTopic getTopic(String topic) {
        return topics.get(topic);
    }
}
