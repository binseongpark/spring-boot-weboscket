package sfaas.mes.websocket;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.Message;
import org.springframework.data.redis.connection.MessageListener;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.messaging.simp.SimpMessageSendingOperations;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.RequiredArgsConstructor;
import sfaas.mes.util.Util;
import sfaas.mes.websocket.model.SocketMessage;

@Configuration
@RequiredArgsConstructor
@Service
public class RedisSubscriber implements MessageListener {
    private final ObjectMapper objectMapper;
    private final RedisTemplate redisTemplate;
    private final SimpMessageSendingOperations messagingTemplate;

    @Value("${server.display-name}")
    private String domain;

    /**
     * Redis에서 메시지가 발행(publish)되면 대기하고 있던 onMessage가 해당 메시지를 받아 처리한다.
     */
    @Override
    public void onMessage(Message message, byte[] pattern) {
        try {
            // redis에서 발행된 데이터를 받아 deserialize
            String publishMessage = (String) redisTemplate.getStringSerializer().deserialize(message.getBody());
            String roomMessage = objectMapper.readValue(publishMessage, String.class);

            SocketMessage socketMessage = Util.jacksonJsonTobean(roomMessage, SocketMessage.class);
            /**
             * socketMessage.getTopic() :
             * log-{domain}
             * notification-{domain}
             * scada-{domain}
             * usercontrol-{domain}
             */

            String websocketUri = Util.split(socketMessage.getTopic(), "-")[0];
            messagingTemplate.convertAndSend("/sub/" + websocketUri, socketMessage.getMessage());
        } catch (Exception e) {
        }
    }
}
