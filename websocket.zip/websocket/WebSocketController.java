package sfaas.mes.websocket;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ResponseBody;

import lombok.RequiredArgsConstructor;
import sfaas.mes.util.Util;
import sfaas.mes.websocket.model.SocketMessage;

@Configuration
@RequiredArgsConstructor
@Controller
public class WebSocketController {

    private final WebSocketRepository webSocketRepository;

    private final RedisPublisher redisPublisher;

    @Autowired
    private WebSocketRepository websocketRepo;

    @Value("${server.display-name}")
    private String domain;

    @MessageMapping("/message")
    @ResponseBody
    public void sendMessage(String message) {

        SocketMessage socketMessage = Util.jacksonJsonTobean(message, SocketMessage.class);

        /**
         * socketMessage.getTopic() :
         * log-{domain}
         * notification-{domain}
         * scada-{domain}
         * usercontrol-{domain}
         */
        domain = Util.split(domain, "-")[0];
        // 신규로 생성된 topic일경우
        if (!StringUtils.equals(socketMessage.getTopic() + "-" + domain, "log-" + domain)
                && !StringUtils.equals(socketMessage.getTopic() + "-" + domain, "notification-" + domain)
                && !StringUtils.equals(socketMessage.getTopic() + "-" + domain, "scada-" + domain)
                && !StringUtils.equals(socketMessage.getTopic() + "-" + domain, "usercontrol-" + domain)) {
            websocketRepo.createTopic(socketMessage.getTopic() + "-" + domain);
            websocketRepo.connectionTopic(socketMessage.getTopic() + "-" + domain);
        }

        redisPublisher.publish(webSocketRepository.getTopic(socketMessage.getTopic() + "-" + domain), message);
    }
}
