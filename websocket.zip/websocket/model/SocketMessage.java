package sfaas.mes.websocket.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SocketMessage {
    private String topic;
    private String message;
}
