package sfaas.mes.websocket;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class WebSocketTopic implements Serializable {
    private String topic;

    public static WebSocketTopic create( String topic ) {
        WebSocketTopic webSocketTopic = new WebSocketTopic();
        webSocketTopic.topic = topic;
        return webSocketTopic;
    }
}
